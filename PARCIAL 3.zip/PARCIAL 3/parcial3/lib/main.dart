import 'package:flutter/material.dart';


class AgregarProductoState extends State<Formulario> {
  final _claveFormulario = GlobalKey<FormState>();
  final TextEditingController _Consultar cliente = TextEditingController();
  final TextEditingController _Consultar mesero = TextEditingController();
  final TextEditingController _Consultar Factura = TextEditingController();
  final TextEditingController _Consultar Platillo = TextEditingController();
    final TextEditingController _Consultar Mesa = TextEditingController()
  final TextEditingController _existencia = TextEditingController();

  Consultar ({Key key}) : super();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Consulta facturas"),
      ),
      body: Form(
        key: _claveFormulario,
        child: ListView(shrinkWrap: true, children: <Widget>[
          Padding(
            padding: EdgeInsets.all(16.0),
            child: TextFormField(
              keyboardType: TextInputType.number,
              validator: (value) {
                if (value.isEmpty) {
                  return 'Escribe el código de barras';
                }
                return null;
              },
              controller:
              decoration: InputDecoration(
                hintText: 'Escribe la consulta',
                ,
              ),
            ),
          ),
          Padding(
            padding: EdgeInsets.all(16.0),
            child: TextFormField(
              validator: (value) {
                if (value.isEmpty) {
                  
                }
                return null;
              },
              controller: _descripcion,
              decoration: InputDecoration(
              ),
            ),
          ),
          Padding(
            padding: EdgeInsets.all(16.0),
            child: TextFormField(
              keyboardType: TextInputType.number,
              validator: (value) {
                if (value.isEmpty) {
                 
                }
                return null;
              },
              controller: _precioCompra,
              decoration: InputDecoration(
               
            ),
          ),
          Padding(
            padding: EdgeInsets.all(16.0),
            child: TextFormField(
              keyboardType: TextInputType.number,
              validator: (value) {
                if (value.isEmpty) {
                }
                return null;
              },
              controller: _precioVenta,
              decoration: InputDecoration(
              
            ),
          ),
          Padding(
            padding: EdgeInsets.all(16.0),
            child: TextFormField(
              keyboardType: TextInputType.number,
              validator: (value) {
                if (value.isEmpty) {
                  return 'Escribe la existencia';
                }
                return null;
              },
              controller: _existencia,
              decoration: InputDecoration(
                hintText: 
              ),
            ),
          ),
          Padding(
            padding: EdgeInsets.all(16.0),
            child: Builder(
              builder: (context) => RaisedButton(
                color: Colors.blue,
                textColor: Colors.white,
                child: cargando
                    ? CircularProgressIndicator(
                        valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                      )
                    : Text("Guardar"),
                onPressed: () async {
                  
}