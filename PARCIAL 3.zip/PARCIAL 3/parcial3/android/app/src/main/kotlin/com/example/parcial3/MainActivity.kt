package com.example.parcial3

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
